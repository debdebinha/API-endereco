// importação do Router do Express e as funções relacionadas aos casos de uso de endereços, cidades e bairros.

import { Router } from 'express';
import { listAddress } from './app/useCases/address/listAddress';
import { createAddress } from './app/useCases/address/createAddress';
import { listCity } from './app/useCases/city/listCity';
import { createCity } from './app/useCases/city/createCity';
import { listNeighborhood } from './app/useCases/neighborhood/listNeighborhood';
import { createNeighborhood } from './app/useCases/neighborhood/createNeighborhood';

// exportação do roteador para que possamos usá-lo em outros lugares do seu aplicativo.
export const router = Router();

//define várias rotas usando o Router. 

//List adress
router.get('/enderecos', listAddress);

//Create adress
router.post('/endereco', createAddress);

//List neighbourhood
router.get('/bairros', listNeighborhood);

//Create neighbourhood
router.post('/bairro', createNeighborhood);

//List city
router.get('/cidades', listCity);

//Create city
router.post('/cidade', createCity);