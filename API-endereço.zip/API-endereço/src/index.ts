// O código começa importando os módulos necessários, incluindo path (para manipulação de caminhos de arquivo), express (para criar o servidor web), mongoose (para interagir com o MongoDB) e o módulo router (que contém as definições de rotas).
import path from 'node:path';
import express from 'express';
import mongoose from 'mongoose';

import { router } from './router'; // Importa as rotas do arquivo router.js

// Configura a conexão com o banco de dados MongoDB
mongoose.connect('mongodb://localhost:27017')
    .then(() => {
        // Configurações do servidor Express
        const app = express(); // instância do Express chamada app 
        const port = 3000; // Porta local do servidor

        app.use('/uploads', express.static(path.resolve(__dirname, '..', 'uploads'))); // configura um middleware para servir arquivos estáticos. Ela permite que os arquivos na pasta 'uploads' sejam acessados via URL no caminho /uploads. Isso é útil para servir arquivos de mídia; como imagens, para clientes.
        app.use(express.json());  // permite o uso de JSON no corpo das solicitações
        app.use(router); // direciona as solicitações HTTP para as rotas definida

        // Inicia o servidor na porta especificada e imprime uma mensagem de sucesso no console
        app.listen(port, () => {
            console.log(`🚗 Server is running on http://localhost:${port}`); // Inicia o servidor Express na porta especificada (3000, neste caso) e exibe uma mensagem no console quando o servidor estiver pronto para receber solicitações.
        });
    })
    // falha de conexão:
    .catch(() => console.log('Error connecting to MongoDB')); // Se a conexão com o MongoDB falhar, uma mensagem de erro será exibida no console.