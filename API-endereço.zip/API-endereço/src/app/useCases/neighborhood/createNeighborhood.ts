// o código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).
import { Request, Response } from 'express';
import { Neighborhood } from '../../models/Neighborhood';

// Função assíncrona para criar um novo bairro
export async function createNeighborhood(req: Request, res: Response) {
    try {
        // Extrai informações do corpo da requisição
        const { name } = req.body;

        // Cria um novo objeto Neighborhood usando o modelo Neighborhood
        const neighborhood = await Neighborhood.create({
            name
        });

        res.status(201).json(neighborhood); // a função responde com um status HTTP 201 (Created) e envia os bairros criada como uma resposta JSON
    } catch (error) { // se ocorrer algum erro durante o processo de consulta dos bairros, ele é capturado pelo bloco catch.
        console.log(error);
        res.sendStatus(500);
    }
}