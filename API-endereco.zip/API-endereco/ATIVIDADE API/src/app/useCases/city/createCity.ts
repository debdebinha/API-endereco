// o código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).
import { Request, Response } from 'express';
import { City } from '../../models/City';

// Função assíncrona para criar uma nova cidade
export async function createCity(req: Request, res: Response) {
    try {
        // Extrai informações do corpo da requisição
        const { name, state } = req.body;

        // Cria um novo objeto City usando o modelo City
        const city = await City.create({
            name,
            state
        });

        res.status(201).json(city); // a função responde com um status HTTP 201 (Created) e envia a categoria criada como uma resposta JSON
    } catch (error) { // se ocorrer algum erro durante o processo de consulta das categorias, ele é capturado pelo bloco catch.
        console.log(error); 
        res.sendStatus(500);
    }
}