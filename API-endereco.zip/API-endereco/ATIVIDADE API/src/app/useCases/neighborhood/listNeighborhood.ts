// o código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).
import { Request, Response } from 'express';
import { Neighborhood } from '../../models/Neighborhood';

// Função assíncrona para listar todos os bairros
export async function listNeighborhood(req: Request, res: Response) {
    try {
        // Busca todos os registros de bairros no banco de dados
        const neighborhoods = await Neighborhood.find(); 

        res.json(neighborhoods); // se a consulta for bem-sucedida, a função responde com um status HTTP 200 (OK) e envia a lista de bairros como uma resposta JSON
    } catch (error) { // se ocorrer algum erro durante o processo de consulta dos bairros, ele é capturado pelo bloco catch.
        console.log(error);
        res.sendStatus(500);
    }
}