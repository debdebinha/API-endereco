// o código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).
import { Request, Response } from 'express';
import { Address } from '../../models/Address';

// Função para criar um novo endereço
export async function createAddress(req: Request, res: Response) {
    try {
        // Extrai informações do corpo da requisição
        const { name, number, complement, neighborhood, city } = req.body;

        // Cria um novo objeto Address usando o modelo Address
        const address = await Address.create({
            name,
            number,
            complement,
            neighborhood,
            city
        });

        res.status(201).json(address); // a função responde com um status HTTP 201 (Created) e envia o endereço criada como uma resposta JSON
    } catch (error) { // se ocorrer algum erro durante o processo de consulta dos endereços, ele é capturado pelo bloco catch.
        console.log(error);
        res.sendStatus(500);
    }
}